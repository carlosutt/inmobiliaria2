<header>
    <h1>Administración de BIENES RAICES</h1>
    <h2>Sistema de Administración Web </h2>
</header>  
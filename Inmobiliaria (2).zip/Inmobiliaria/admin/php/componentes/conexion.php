<?php
$server ="localhost";
$username ="root";
$password ="12345678";
$bd       ="sawpi_bd";

$conn = mysqli_connect($server, $username, $password, $bd);

if(!$conn){
    die("Conexion faillida:" . mysqli_connect_error());
}

if(!$conn){
    die("Conexion faillida:" . mysqli_connect_error());
}

?>
Inmobiliaria Web - Desarrollado Por INNCODE <br>
<?php echo $config['telefono1'] . " - " . $config['email_contacto'] ?>